# EU AI Act Article 12 record-keeping report

Generated 2026-09-24T18:43:20Z by Vaara 1.97.1.

## System

| Field | Value |
| --- | --- |
| System name | not provided |
| Provider | not provided |
| Deployer | not provided |
| Intended purpose | not provided |
| Risk classification | not provided |
| Export created (UTC) | 2026-09-24T18:43:20Z |
| Signer fingerprint | 114aad3b512ac166e81754fb1ca740a4 |
| Signature algorithm | Ed25519 |

## Record-keeping summary

| Field | Value |
| --- | --- |
| Records in signed trail | 8 |
| Records in reporting scope | 8 |
| First event (UTC) | 2026-09-24T18:43:20Z |
| Last event (UTC) | 2026-09-24T18:43:20Z |
| Hash chain intact at export | True |
| Trail SHA-256 | db4b7132a29664f557a844c253d441da5eded7071ac7763f1cb094b1bd748bd7 |

## Article 12 obligation mapping

| Obligation | Title | Status | Records | Event types present |
| --- | --- | --- | --- | --- |
| Article 12(1) | Automatic recording of events over the system lifetime | evidenced | 8 | action_requested, decision_made, action_executed, outcome_recorded |
| Article 12(2)(a) | Identifying situations that may present a risk (Article 79(1)) or a substantial modification | evidenced | 2 | outcome_recorded |
| Article 12(2)(b) | Facilitating post-market monitoring (Article 72) | evidenced | 4 | outcome_recorded, action_executed |
| Article 12(2)(c) / 26(5) | Monitoring of operation by the deployer | evidenced | 4 | decision_made, action_executed |
| Article 12(3)(a) | Period of each use (start and end of operation) | evidenced | 4 | action_requested, action_executed |
| Article 19(1) | Keeping the automatically generated logs under the deployer's control for the appropriate retention period | evidenced | 8 | action_requested, decision_made, action_executed, outcome_recorded |

## Event inventory

| Event type | Count | First (UTC) | Last (UTC) |
| --- | --- | --- | --- |
| action_executed | 2 | 2026-09-24T18:43:20Z | 2026-09-24T18:43:20Z |
| action_requested | 2 | 2026-09-24T18:43:20Z | 2026-09-24T18:43:20Z |
| decision_made | 2 | 2026-09-24T18:43:20Z | 2026-09-24T18:43:20Z |
| outcome_recorded | 2 | 2026-09-24T18:43:20Z | 2026-09-24T18:43:20Z |

## Integrity

Hash chain intact at export: True.
Signature algorithm: Ed25519.
Trail SHA-256: db4b7132a29664f557a844c253d441da5eded7071ac7763f1cb094b1bd748bd7.

A valid signature proves the integrity and provenance of these logs. It does not prove the truth of every recorded assertion.
See docs/signing-keys.md and the trust model for the boundary.

## External time anchor (Article 19)

No external time anchor is included in this package. The signature proves integrity and provenance; on its own it does not prove when the logs existed. Add an RFC 3161 (eIDAS-qualified) time anchor with: vaara trail export-article12 --anchor-tsa <url>.

## Cross-org handoff and enforcement evidence

### Cross-org handoff custody (Article 26(6))

| Field | Value |
| --- | --- |
| Packages folded | 1 |
| Verify under rotated-out key | 1 |
| Verifiable | 1 |
| Anchor-corroborated | 1 |
| Producer pinned (out of band) | 1 |

A handoff is verifiable when the record's signature binds to a key the archived DID document lists, inside that key's validity window, and the key was not revoked before issuance. It is corroborated only when an enclosed eIDAS time anchor predates the key's retirement and revocation. Producer identity is pinned only when checked against a DID document trusted out of band; otherwise it is self-asserted. Where a record is neither corroborated nor pinned, its authenticity rests on the signature against a self-asserted identity.

## How to verify

How to verify this Article 12 package

1. Check the signature over the signed trail and manifest:
     python scripts/verify_vaara_trail.py <this_package>.zip
   or, with Vaara installed:
     vaara trail verify --zip <this_package>.zip

2. Confirm this report describes the signed trail. The trail_sha256
   recorded in this report and in article12_summary.json must equal
   the trail_sha256 in manifest.json:
     db4b7132a29664f557a844c253d441da5eded7071ac7763f1cb094b1bd748bd7

3. Re-verify the folded SEP-2828 evidence from the bytes in evidence/.
   These sidecars are verified at export and fail the export if they do not
   verify; re-check them independently:
     vaara verify-handoffs evidence/handoff
   or the Vaara-free checker in tests/vectors/cross_org_handoff_v0/.
   The roll-up in evidence/attestations_summary.json must match what you
   reproduce. A handoff is not corroborated without a verified anchor, and an
   enforcement binding is not attested: the VCEK chain to AMD's root is not
   validated in this release. The eIDAS time anchor stays the only un-forgeable
   component of this package.

The signature covers trail.jsonl and manifest.json. This report and
article12_summary.json are a derived, human-readable view bound to the
signed trail by the trail_sha256 above. They are not themselves signed.
The folded evidence/ sidecars are content-addressed SEP-2828 records, verified
at export; they are not covered by the trail signature.
